@extends ('template')

@section('titre')
Mon site
@endsection

@section('contenu')
Bienvenue sur mon site en Laravel
@endsection