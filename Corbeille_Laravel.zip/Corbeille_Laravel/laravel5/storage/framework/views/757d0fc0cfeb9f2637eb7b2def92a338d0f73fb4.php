<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('titre'); ?></title>
</head>
<body>
	<?php echo $__env->yieldContent('contenu'); ?>
</body>
</html>